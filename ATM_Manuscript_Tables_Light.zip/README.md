# Supplementary Computational Suite: Modular Projection Sieving

**Companion artifact to:**
*Algebraic Theory of Modular Projection Sieving: Prime-Coprime Entanglement and Asymmetric Activation Thresholds*
**Author:** José Ignacio Peinador Sala
**ORCID:** [0009-0008-1822-3452](https://orcid.org/0009-0008-1822-3452)
**Target Journal:** *Mathematics of Computation* (AMS)
**Archive Deposit Date:** October 2026
**Zenodo DOI (Permanent Archive):** [10.5281/zenodo.22043294](https://doi.org/10.5281/zenodo.22043294)

---

## 1. Overview & Verification Scope

This archive provides the self-contained experimental validation suite, datasets, LaTeX tables, high-resolution figures, and cryptographic verification manifests supporting the manuscript. It consolidates:
1. **Sieve Scalability Benchmarks (Table 1):** Wall-clock timings, memory footprints, and complexity transition ratios for the state-vectorless $\kappa_{\min}^\pm$ sieve up to $N \approx 3 \times 10^8$.
2. **Multi-Scale Entanglement Spectra (Table 2):** Distribution of the positional jump $\Delta k(p) = \operatorname{NextKop}(p) - k_p$ across scales ($N \sim 6 \times 10^7, 6 \times 10^8, 10^9$) with 95% Wilson confidence intervals.
3. **Extremal Records of $j_6(p)$ & Model Selection (§5.5):** Complete tabulation of all 33 records up to $j_6 = 98$ at $p = 680{,}676{,}119$, evaluated against competing asymptotic models via AIC/BIC and Hill tail diagnostics.
4. **Chiral Convergence (§5.4):** Decadic empirical monitoring of channel parity $c_1(x)/c_5(x)$ and power-law decay rate ($1 - c_1/c_5 \sim C x^{-\alpha}$ with $\alpha \approx 0.47$).
5. **Modular Jacobsthal via Segmented CRT (Appendix):** Exact composite runs $j_{\mathcal{C}_1}(z)$ for primorial periods up to $z = 29$ ($M \approx 1.08 \times 10^9$) verifying the bound $j_6(p_{\max}) \le j_{\mathcal{C}_1}(z)$.

---

## 2. Benchmark Environment Telemetry

All benchmark timings and numerical artifacts were produced in the following single-threaded audited environment:
* **Host CPU:** AMD EPYC 7B12
* **Core Count / Execution Threads:** 1 core(s) / 1 single thread (isolated via `OMP/NUMBA/MKL=1`)
* **SIMD Instruction Extensions:** sse4_2 avx avx2
* **Total Physical RAM:** 12Gi
* **Operating System:** Ubuntu 24.04.5 LTS (Kernel: 6.6.122+)
* **Software Stack:** Python 3.13.16, NumPy 2.1.3, Numba 0.61.2, SciPy 1.16.3
* **Monotonic Timer Resolution:** Monotonic nanosecond timer (`time.perf_counter_ns()`)
* **Global Deterministic Seed:** `numpy.random.seed(42)`

---

## 3. Directory Inventory & Artifact Map


```

/content/results/
├── Manifests & Metadata:
│    ├── hardware.json                  (Complete hardware telemetry audit)
│    ├── MANIFEST.json                  (Cryptographic manifest with SHA-256 digests)
│    ├── README.md                      (This document)
│    └── consolidated_summary.csv       (Unified flat table linking all findings)
│
├── Table 1 & Sieve Scalability:
│    ├── table_1.tex                    (Formatted LaTeX source matching Table 1 in paper)
│    ├── table_ratios.tex               (Formatted LaTeX source matching Table 2 in paper)
│    ├── table_1.csv                    (Flat CSV data across scales N = 6,001 to 300,000,001)
│    ├── table_1.json                   (Detailed telemetry with bootstrap CIs and CV%)
│    └── table_1_plots.png              (3-panel figure: Time scaling, Memory scaling, Chiral ratio)
│
├── Table 2 & Entanglement Spectrum:
│    ├── table_2.tex                    (Formatted LaTeX source matching Table 2 in paper)
│    ├── table_2.csv                    (Long-form CSV distribution per scale)
│    ├── table_2.json                   (Multi-scale spectrum with exact Wilson 95% CIs)
│    └── table_2_plots.png              (2-panel figure: Jump distribution & cumulative CDF)
│
├── High-Scale Sieve Datasets:
│    ├── sieve_1e9.npz                  (50.8M primes with positional index kp and channel eps)
│    └── delta_k_1e9.npz                (25.4M entanglement jumps for C5->C1 and C1->C5)
│
├── Chiral Convergence:
│    ├── table_chiral_convergence.tex   (LaTeX table across decade milestones)
│    ├── chiral_convergence.csv         (Flat CSV of chiral metrics)
│    ├── chiral_fit.json                (Regression coefficients and decay fit metadata)
│    └── chiral_convergence_plots.png   (Trajectory and log-log decay rate plots)
│
├── Extremal Records of j_6(p):
│    ├── table_j6_records.tex           (Complete LaTeX table of all 33 records up to j_6 = 98)
│    ├── j6_records.csv                 (Tabulated CSV records)
│    ├── j6_records.json                (Full record catalog with log_p depths)
│    ├── j6_records.npz                 (Compact NumPy binary for model fitting)
│    └── j6_records_plots.png           (Step-function envelope plots vs p and ln(p))
│
├── Model Selection (§5.5):
│    ├── table_j6_models.tex            (LaTeX table comparing Model A vs Model B)
│    ├── j6_models.csv                  (CSV of AIC, BIC, RSS and bootstrap intervals)
│    ├── j6_models.json                 (Model parameters and decision statistics)
│    └── j6_growth_aic.png              (2-panel figure: Candidate envelopes & residual plots)
│
├── Tail Regime Diagnosis:
│    ├── table_hill_diagnosis.tex       (LaTeX table of Hill estimates across order statistics)
│    ├── hill_diagnosis.csv             (CSV profile of Hill index drift)
│    ├── hill_diagnosis.json            (Quantile moments and Hill drift diagnostics)
│    └── hill_plot.png                  (2-panel figure: Empirical CCDF & Hill stability plot)
│
└── Modular Jacobsthal & Conjecture Verification:
├── table_jacobsthal_crt.tex       (LaTeX table comparing j_{C1} with classical Jacobsthal)
├── jacobsthal_crt.csv             (CSV table for z <= 29)
├── jacobsthal_crt.json            (Detailed CRT run logs and t-test statistics)
├── jacobsthal_crt.npz             (Compact NumPy arrays for moduli z <= 29)
├── jacobsthal_crt_plots.png       (Jacobsthal growth and four-fold reduction ratio plots)
├── table_conjecture.tex           (LaTeX table verifying j_6(p_max) <= j_{C1}(z))
├── table_conjecture.csv           (CSV table of conjecture checks and margins)
├── conjecture_verification.json   (Margin slope and linear regression metrics)
└── conjecture_margin.png          (Domination bounds & safety margin expansion plots)

```

---

## 4. Summary of Key Findings

1. **State-Vectorless Scalability matches RAM Lower Bound:**
   Empirical wall-clock times adhere to $T(N) = \Theta(N^{3/2}/\log N)$ with transition ratio discrepancies below 5% for all $N \ge 10^6$. Working memory footprint remains bounded by the base primes table size $\Theta(\sqrt{N}/\log N)$, consuming less than $100$ KB at $N = 3 \times 10^8$.
2. **Entanglement Ground State ($\Delta k = 0$) reflects Twin Primes:**
   The vanishing of the entanglement jump $\Delta k(p) = 0$ is a strictly local ground state. Its frequency decays monotonically with scale: $15.75\%$ at $N \sim 6 \times 10^7 \longrightarrow 13.83\%$ at $N \sim 6 \times 10^8 \longrightarrow 13.47\%$ at $N = 10^9$. Over $49.5\%$ of all projections satisfy $\Delta k \le 3$.
3. **Indistinguishable Extremal Envelopes ($|\Delta\text{AIC}| < 2$):**
   Over the asymptotic range ($p \ge 1{,}000$), Model A ($j_6(p) \sim a (\ln p)^\alpha$ with $\alpha \approx 2.85$) and Model B ($j_6(p) \sim c \exp(\beta \sqrt{\ln p})$ with $\beta \approx 1.43$) yield $|\Delta\text{AIC}| = 1.02$, proving that existing computational scales cannot discriminate between a power law and an exponential envelope.
4. **Absence of Pareto Tail Regime:**
   The Hill tail estimator $\hat{\xi}(k)$ drifts continuously from $0.13$ to $0.34$ across upper order statistics without developing a horizontal plateau, confirming that the jump distribution is not Pareto heavy-tailed and formally superseding preliminary conjectures of $\alpha \approx 0.13$.
5. **Four-Fold Gap Reduction via Modular Jacobsthal:**
   Over all primorial periods $M(z) = \prod_{3 < p \le z} p$ up to $z = 29$ ($M \approx 1.08 \times 10^9$), the maximal composite index run in the unit channel satisfies $j_{\mathcal{C}_1}(z) / j_{\text{classic}}(z) \approx 0.2116 \approx 1/4.5$. The positional conjecture $j_6(\lfloor z^2/6 \rfloor) \le j_{\mathcal{C}_1}(z)$ holds with a safety margin expanding at slope $+0.3301 \cdot z$ ($R^2 = 0.9704$).

---

## 5. Instructions for Exact Reproduction

### Via Google Colab (Zero Installation)
1. Open Google Colab and upload the notebook `Algebraic_Theory_of_Modular_Projection_Sieving.ipynb`.
2. Select **Runtime -> Run all** (or execute Cell 2 through Cell 14 sequentially).
3. The total CPU runtime is approximately 85–95 minutes on standard Colab Xeon instances.
4. Download the generated reproducible archives directly via Cell 14.

### Via Local Python Environment
Ensure Python $\ge 3.10$ and install prerequisites:
```bash
pip install numpy numba scipy pandas matplotlib

```

Run the notebook or extract the Python script:

```bash
jupyter nbconvert --to script Algebraic_Theory_of_Modular_Projection_Sieving.ipynb
python Algebraic_Theory_of_Modular_Projection_Sieving.py

```

---

## 6. Licensing & Attribution

* **Source Code:** MIT License (c) 2026 José Ignacio Peinador Sala.
* **Datasets, Figures & Tables:** Creative Commons Attribution 4.0 International (CC-BY 4.0).
* **Lean 4 Verification Suite:** Self-contained and archived under Apache 2.0 / MIT licenses at Zenodo DOI: `10.5281/zenodo.22043294`.
