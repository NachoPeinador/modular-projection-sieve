import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

open Finset

namespace ATM.TwinPrimesExt

-- ============================================================================
-- 1. DEFINICIONES BASE (DISCRETAS Y ASINTÓTICAS)
-- ============================================================================

/-- Base de números primos impares p ≥ 5 hasta la cota z. -/
def prime_basis (z : ℕ) : Finset ℕ :=
  (Finset.range (z + 1)).filter (fun p => 5 ≤ p ∧ Nat.Prime p)

/-- Primorial modificado M(z) = P(z)/6 sobre los primos p ≥ 5. -/
def M (z : ℕ) : ℕ :=
  ∏ p ∈ prime_basis z, p

/-- Cardinalidad combinatoria exacta de clases residuales supervivientes en ℕ. -/
def surviving_cardinality (z : ℕ) : ℕ :=
  ∏ p ∈ prime_basis z, (p - 2)

/-- Densidad estocástica clásica de coprimalidad doble en ℝ. -/
noncomputable def coprime_density (z : ℕ) : ℝ :=
  ∏ p ∈ prime_basis z, (1 - 1 / (p : ℝ)) ^ 2

/-- Factor singular de Hardy-Littlewood en ℝ (corrección determinista del aniquilador). -/
noncomputable def hardy_littlewood_factor (z : ℕ) : ℝ :=
  ∏ p ∈ prime_basis z, (1 - 1 / ((p : ℝ) - 1) ^ 2)

/-- Densidad exacta de supervivencia del aniquilador cuadrático en ℝ. -/
noncomputable def survival_density (z : ℕ) : ℝ :=
  ∏ p ∈ prime_basis z, (((p : ℝ) - 2) / (p : ℝ))

-- ============================================================================
-- 2. TEOREMAS DISCRETOS (POSITIVIDAD EN ℕ)
-- ============================================================================

/-- Teorema N1: La cardinalidad de candidatos a gemelos es estrictamente positiva
    dentro del periodo fundamental CRT para todo z ≥ 5. -/
theorem surviving_cardinality_pos (z : ℕ) (hz : 5 ≤ z) : 0 < surviving_cardinality z := by
  dsimp [surviving_cardinality]
  apply prod_pos
  intro p hp
  rw [prime_basis, mem_filter, mem_range] at hp
  omega

/-- Teorema N1: El primorial modificado M(z) es estrictamente positivo. -/
theorem M_pos (z : ℕ) : 0 < M z := by
  dsimp [M]
  apply prod_pos
  intro p hp
  rw [prime_basis, mem_filter, mem_range] at hp
  omega

-- ============================================================================
-- 3. LEMAS AUXILIARES DE ACOTACIÓN EN ℝ
-- ============================================================================

lemma p_ge_five (p : ℕ) (hp : p ∈ prime_basis z) : (5 : ℝ) ≤ (p : ℝ) := by
  rw [prime_basis, mem_filter, mem_range] at hp
  exact Nat.cast_le.mpr hp.2.1

lemma p_gt_one (p : ℕ) (hp : p ∈ prime_basis z) : (1 : ℝ) < (p : ℝ) := by
  have := p_ge_five p hp
  linarith

lemma p_ne_zero (p : ℕ) (hp : p ∈ prime_basis z) : (p : ℝ) ≠ 0 := by
  have := p_ge_five p hp
  linarith

lemma p_ne_one (p : ℕ) (hp : p ∈ prime_basis z) : (p : ℝ) ≠ 1 := by
  have := p_ge_five p hp
  linarith

-- ============================================================================
-- 4. IDENTIDAD LOCAL Y FACTORIZACIÓN DE HARDY-LITTLEWOOD EN ℝ
-- ============================================================================

/-- Teorema N1: Identidad algebraica local de Hardy-Littlewood sobre un cuerpo.
    Demostrada puramente mediante normalización de cuerpos con cero axiomas. -/
theorem hl_local_identity (p : ℝ) (hp0 : p ≠ 0) (hp1 : p ≠ 1) :
    (p - 2) / p = (1 - 1 / p) ^ 2 * (1 - 1 / (p - 1) ^ 2) := by
  have h1 : p - 1 ≠ 0 := sub_ne_zero.mpr hp1
  have hsq1 : (1 - 1 / p) ^ 2 = (1 - 1 / p) * (1 - 1 / p) := by ring
  have hsq2 : (p - 1) ^ 2 = (p - 1) * (p - 1) := by ring
  rw [hsq1, hsq2]
  field_simp
  ring

/-- Teorema N1: Factorización global de la densidad de supervivencia.
    La densidad en el sub-retículo se factoriza idénticamente en la densidad
    estocástica por el producto de factores de Hardy-Littlewood. -/
theorem density_factorization (z : ℕ) :
    survival_density z = coprime_density z * hardy_littlewood_factor z := by
  dsimp [survival_density, coprime_density, hardy_littlewood_factor]
  have h_step : ∏ p ∈ prime_basis z, (((p : ℝ) - 2) / (p : ℝ)) =
                ∏ p ∈ prime_basis z, ((1 - 1 / (p : ℝ)) ^ 2 * (1 - 1 / ((p : ℝ) - 1) ^ 2)) := by
    apply prod_congr rfl
    intro p hp
    exact hl_local_identity (p : ℝ) (p_ne_zero p hp) (p_ne_one p hp)
  rw [h_step]
  exact prod_mul_distrib

/-- Teorema N1: Evaluación numérica puntual en el anclaje p = 5. -/
theorem hl_local_factor_at_5 :
    ((5 : ℝ) - 2) / 5 = (1 - 1 / (5 : ℝ)) ^ 2 * (1 - 1 / ((5 : ℝ) - 1) ^ 2) := by
  exact hl_local_identity 5 (by norm_num) (by norm_num)

-- ============================================================================
-- 5. RELACIÓN MULTIPLICATIVA ENTRE EL PRIMORIAL Y LOS SUPERVIVIENTES
-- ============================================================================

/-- Teorema N1: Relación canónica entre la densidad continua y las cantidades discretas.
    M(z) * survival_density(z) = ∏ (p - 2). -/
theorem survival_density_mul_M (z : ℕ) :
    (∏ p ∈ prime_basis z, (p : ℝ)) * survival_density z = ∏ p ∈ prime_basis z, ((p : ℝ) - 2) := by
  dsimp [survival_density]
  rw [← prod_mul_distrib]
  apply prod_congr rfl
  intro p hp
  exact mul_div_cancel₀ ((p : ℝ) - 2) (p_ne_zero p hp)

-- ============================================================================
-- 6. POSITIVIDAD DE LOS FACTORES ASINTÓTICOS
-- ============================================================================

lemma coprime_factor_pos (p : ℕ) (hp : p ∈ prime_basis z) :
    0 < (1 - 1 / (p : ℝ)) ^ 2 := by
  have hp0 : 0 < (p : ℝ) := by have := p_ge_five p hp; linarith
  have h_frac : 1 / (p : ℝ) < 1 := by
    rw [div_lt_iff₀ hp0]
    have := p_ge_five p hp
    linarith
  have h_sub : 0 < 1 - 1 / (p : ℝ) := by linarith
  have h_sq : (1 - 1 / (p : ℝ)) ^ 2 = (1 - 1 / (p : ℝ)) * (1 - 1 / (p : ℝ)) := by ring
  rw [h_sq]
  exact mul_pos h_sub h_sub

lemma hl_factor_pos (p : ℕ) (hp : p ∈ prime_basis z) :
    0 < 1 - 1 / ((p : ℝ) - 1) ^ 2 := by
  have hp5 := p_ge_five p hp
  have h_p1_pos : 0 < (p : ℝ) - 1 := by linarith
  have h_sq_pos : 0 < ((p : ℝ) - 1) ^ 2 := by
    have h_sq : ((p : ℝ) - 1) ^ 2 = ((p : ℝ) - 1) * ((p : ℝ) - 1) := by ring
    rw [h_sq]
    exact mul_pos h_p1_pos h_p1_pos
  have h_frac : 1 / ((p : ℝ) - 1) ^ 2 < 1 := by
    rw [div_lt_iff₀ h_sq_pos]
    nlinarith
  linarith

/-- Teorema N1: La densidad coprima doble es estrictamente positiva. -/
theorem coprime_density_pos (z : ℕ) : 0 < coprime_density z := by
  dsimp [coprime_density]
  apply prod_pos
  intro p hp
  exact coprime_factor_pos p hp

/-- Teorema N1: El factor compuesto de Hardy-Littlewood es estrictamente positivo. -/
theorem hardy_littlewood_factor_pos (z : ℕ) : 0 < hardy_littlewood_factor z := by
  dsimp [hardy_littlewood_factor]
  apply prod_pos
  intro p hp
  exact hl_factor_pos p hp

/-- Teorema N1: La densidad total de supervivencia al aniquilador cuadrático
    es estrictamente positiva en ℝ para cualquier escala z. -/
theorem survival_density_pos (z : ℕ) : 0 < survival_density z := by
  rw [density_factorization z]
  exact mul_pos (coprime_density_pos z) (hardy_littlewood_factor_pos z)

end ATM.TwinPrimesExt
