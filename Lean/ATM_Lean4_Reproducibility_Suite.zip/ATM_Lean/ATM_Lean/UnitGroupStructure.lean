import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.GCD.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Tactic

namespace ATM.UnitGroup

/-- §2.1: 5 is the involutive unit of Z/6Z (5 * 5 ≡ 1). -/
theorem involution_mul : (5 * 5) % 6 = 1 % 6 := by norm_num

/-- §2.1: 1 + 5 ≡ 0 mod 6 (chiral antisymmetry). -/
theorem involution_add : (1 + 5) % 6 = 0 % 6 := by norm_num

/-- §2.1: the unit group (Z/6Z)× is exactly {1, 5}. -/
theorem unit_group_is :
    (Finset.filter (fun x : ℕ => x.Coprime 6) (Finset.range 6)) = {1, 5} := by decide

end ATM.UnitGroup
