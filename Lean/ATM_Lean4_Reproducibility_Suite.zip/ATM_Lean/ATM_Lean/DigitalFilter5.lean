import Mathlib.Data.Int.Basic
import Mathlib.Tactic

namespace ATM.Filter5

/-- Thm 3.9 (mod 5, C1 channel): 5 | (6k + 1) - (k + 1).
    Equivalently, 6k + 1 ≡ k + 1 (mod 5). -/
theorem filter_mod_5_positive (k : ℤ) : 5 ∣ (6 * k + 1) - (k + 1) := by omega

/-- Thm 3.9 (mod 5, C5 channel): 5 | (6k - 1) - (k - 1).
    Equivalently, 6k - 1 ≡ k - 1 (mod 5). -/
theorem filter_mod_5_negative (k : ℤ) : 5 ∣ (6 * k - 1) - (k - 1) := by omega

/-- Corollary: the C1 reduction 5 | 6k + 1 ↔ 5 | k + 1. -/
theorem filter_c1_iff (k : ℤ) : (5 ∣ (6 * k + 1)) ↔ (5 ∣ (k + 1)) := by
  constructor
  · intro h
    have := filter_mod_5_positive k
    have hsub : k + 1 = (6 * k + 1) - ((6 * k + 1) - (k + 1)) := by ring
    rw [hsub]
    exact dvd_sub h this
  · intro h
    have := filter_mod_5_positive k
    have hadd : 6 * k + 1 = (k + 1) + ((6 * k + 1) - (k + 1)) := by ring
    rw [hadd]
    exact dvd_add h this

/-- Corollary: the C5 reduction 5 | 6k - 1 ↔ 5 | k - 1. -/
theorem filter_c5_iff (k : ℤ) : (5 ∣ (6 * k - 1)) ↔ (5 ∣ (k - 1)) := by
  constructor
  · intro h
    have := filter_mod_5_negative k
    have hsub : k - 1 = (6 * k - 1) - ((6 * k - 1) - (k - 1)) := by ring
    rw [hsub]
    exact dvd_sub h this
  · intro h
    have := filter_mod_5_negative k
    have hadd : 6 * k - 1 = (k - 1) + ((6 * k - 1) - (k - 1)) := by ring
    rw [hadd]
    exact dvd_add h this

end ATM.Filter5
