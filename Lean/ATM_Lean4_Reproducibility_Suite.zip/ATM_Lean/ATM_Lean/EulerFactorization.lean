import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

namespace ATM.EulerFactorization

open Classical

/-- §2.1 (N1): every prime p > 3 lies in C1 or C5. -/
theorem domain_primes_mod_6 (p : ℕ) (hp : Nat.Prime p) (hp3 : 3 < p) :
    p % 6 = 1 ∨ p % 6 = 5 := by
  have h_mod : p % 6 = 0 ∨ p % 6 = 1 ∨ p % 6 = 2 ∨ p % 6 = 3 ∨ p % 6 = 4 ∨ p % 6 = 5 := by omega
  rcases h_mod with h0 | h1 | h2 | h3 | h4 | h5
  · exfalso
    have h_div : 2 ∣ p := ⟨3 * (p / 6), by omega⟩
    have hp_eq_2 : 2 = p := (hp.eq_one_or_self_of_dvd 2 h_div).resolve_left (by decide)
    omega
  · exact Or.inl h1
  · exfalso
    have h_div : 2 ∣ p := ⟨3 * (p / 6) + 1, by omega⟩
    have hp_eq_2 : 2 = p := (hp.eq_one_or_self_of_dvd 2 h_div).resolve_left (by decide)
    omega
  · exfalso
    have h_div : 3 ∣ p := ⟨2 * (p / 6) + 1, by omega⟩
    have hp_eq_3 : 3 = p := (hp.eq_one_or_self_of_dvd 3 h_div).resolve_left (by decide)
    omega
  · exfalso
    have h_div : 2 ∣ p := ⟨3 * (p / 6) + 2, by omega⟩
    have hp_eq_2 : 2 = p := (hp.eq_one_or_self_of_dvd 2 h_div).resolve_left (by decide)
    omega
  · exact Or.inr h5

/-- Euler factor at prime p. -/
noncomputable def eulerFactor (p : ℕ) (s : ℝ) : ℝ := (1 - (p : ℝ)^(-s))⁻¹

/-- Product over all primes up to N. -/
noncomputable def totalProd (s : ℝ) : ℕ → ℝ
| 0 => 1
| n + 1 => if Nat.Prime (n + 1) then totalProd s n * eulerFactor (n + 1) s else totalProd s n

/-- Product over primes in channels C1 ∪ C5 up to N. -/
noncomputable def prodChannels (s : ℝ) : ℕ → ℝ
| 0 => 1
| n + 1 => if Nat.Prime (n + 1) ∧ ((n + 1) % 6 = 1 ∨ (n + 1) % 6 = 5) then
             prodChannels s n * eulerFactor (n + 1) s
           else
             prodChannels s n

/-- §2.1 (N1): explicit inductive separation at k = 0. -/
theorem prod_eq_shift (k : ℕ) (s : ℝ) :
    totalProd s (k + 3) = prodChannels s (k + 3) * eulerFactor 2 s * eulerFactor 3 s := by
  induction k with
  | zero =>
    have ht0 : totalProd s 0 = 1 := rfl
    have ht1 : totalProd s 1 = 1 := by
      have eq : totalProd s 1 = if Nat.Prime 1 then totalProd s 0 * eulerFactor 1 s else totalProd s 0 := rfl
      rw [eq, if_neg Nat.not_prime_one, ht0]
    have ht2 : totalProd s 2 = eulerFactor 2 s := by
      have eq : totalProd s 2 = if Nat.Prime 2 then totalProd s 1 * eulerFactor 2 s else totalProd s 1 := rfl
      rw [eq, if_pos Nat.prime_two, ht1, one_mul]
    have ht3 : totalProd s 3 = eulerFactor 2 s * eulerFactor 3 s := by
      have eq : totalProd s 3 = if Nat.Prime 3 then totalProd s 2 * eulerFactor 3 s else totalProd s 2 := rfl
      rw [eq, if_pos Nat.prime_three, ht2]
    have hc0 : prodChannels s 0 = 1 := rfl
    have hc1 : prodChannels s 1 = 1 := by
      have eq : prodChannels s 1 = if Nat.Prime 1 ∧ (1 % 6 = 1 ∨ 1 % 6 = 5) then prodChannels s 0 * eulerFactor 1 s else prodChannels s 0 := rfl
      have h_neg : ¬ (Nat.Prime 1 ∧ (1 % 6 = 1 ∨ 1 % 6 = 5)) := fun h => Nat.not_prime_one h.1
      rw [eq, if_neg h_neg, hc0]
    have hc2 : prodChannels s 2 = 1 := by
      have eq : prodChannels s 2 = if Nat.Prime 2 ∧ (2 % 6 = 1 ∨ 2 % 6 = 5) then prodChannels s 1 * eulerFactor 2 s else prodChannels s 1 := rfl
      have h_neg : ¬ (Nat.Prime 2 ∧ (2 % 6 = 1 ∨ 2 % 6 = 5)) := fun h => by have := h.2; omega
      rw [eq, if_neg h_neg, hc1]
    have hc3 : prodChannels s 3 = 1 := by
      have eq : prodChannels s 3 = if Nat.Prime 3 ∧ (3 % 6 = 1 ∨ 3 % 6 = 5) then prodChannels s 2 * eulerFactor 3 s else prodChannels s 2 := rfl
      have h_neg : ¬ (Nat.Prime 3 ∧ (3 % 6 = 1 ∨ 3 % 6 = 5)) := fun h => by have := h.2; omega
      rw [eq, if_neg h_neg, hc2]
    rw [ht3, hc3]
    ring
  | succ n ih =>
    have eq1 : totalProd s (n + 4) = if Nat.Prime (n + 4) then totalProd s (n + 3) * eulerFactor (n + 4) s else totalProd s (n + 3) := rfl
    have eq2 : prodChannels s (n + 4) = if Nat.Prime (n + 4) ∧ ((n + 4) % 6 = 1 ∨ (n + 4) % 6 = 5) then prodChannels s (n + 3) * eulerFactor (n + 4) s else prodChannels s (n + 3) := rfl
    rw [eq1, eq2]
    by_cases hp : Nat.Prime (n + 4)
    · have h_gt : n + 4 > 3 := by omega
      have h_mod := domain_primes_mod_6 (n + 4) hp h_gt
      have c2 : Nat.Prime (n + 4) ∧ ((n + 4) % 6 = 1 ∨ (n + 4) % 6 = 5) := ⟨hp, h_mod⟩
      rw [if_pos hp, if_pos c2, ih]
      ring
    · have c2 : ¬ (Nat.Prime (n + 4) ∧ ((n + 4) % 6 = 1 ∨ (n + 4) % 6 = 5)) := fun h => hp h.1
      rw [if_neg hp, if_neg c2, ih]

/-- §2.1 (N1): finite Euler factorization (paper: rem:zeta, finite form). -/
theorem finite_euler_factorization_mod_6 (k : ℕ) (s : ℝ)
    (h2 : 1 - (2:ℝ)^(-s) ≠ 0) (h3 : 1 - (3:ℝ)^(-s) ≠ 0) :
    prodChannels s (k + 3) = totalProd s (k + 3) *
      (1 - (2:ℝ)^(-s)) * (1 - (3:ℝ)^(-s)) := by
  rw [prod_eq_shift k s]
  unfold eulerFactor
  generalize hA : (1 - (2:ℝ)^(-s)) = A
  generalize hB : (1 - (3:ℝ)^(-s)) = B
  have hA_neq : A ≠ 0 := by rwa [←hA]
  have hB_neq : B ≠ 0 := by rwa [←hB]
  calc
    prodChannels s (k + 3) = prodChannels s (k + 3) * 1 * 1 := by ring
    _ = prodChannels s (k + 3) * (A⁻¹ * A) * (B⁻¹ * B) := by
        rw [inv_mul_cancel₀ hA_neq, inv_mul_cancel₀ hB_neq]
    _ = prodChannels s (k + 3) * A⁻¹ * B⁻¹ * A * B := by ring

end ATM.EulerFactorization
