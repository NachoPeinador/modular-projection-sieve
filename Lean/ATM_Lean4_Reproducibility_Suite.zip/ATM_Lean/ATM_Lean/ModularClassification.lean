import Mathlib.Data.Nat.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Tactic

namespace ATM.Classification

def C1 (k : ℤ) : ℤ := 6 * k + 1
def C5 (k : ℤ) : ℤ := 6 * k - 1

theorem class_0_even (k N : ℕ) (h : N = 6 * k) : ∃ m, N = 2 * m :=
  ⟨3 * k, by omega⟩

theorem class_0_div_three (k N : ℕ) (h : N = 6 * k) : ∃ n, N = 3 * n :=
  ⟨2 * k, by omega⟩

theorem class_2_even (k N : ℕ) (h : N = 6 * k + 2) : ∃ m, N = 2 * m :=
  ⟨3 * k + 1, by omega⟩

theorem class_3_div_three (k N : ℕ) (h : N = 6 * k + 3) : ∃ n, N = 3 * n :=
  ⟨2 * k + 1, by omega⟩

theorem class_4_even (k N : ℕ) (h : N = 6 * k + 4) : ∃ m, N = 2 * m :=
  ⟨3 * k + 2, by omega⟩

/-- §2.1 (N1): every prime p > 3 lies in C1 or C5, i.e., p ≡ 1 or 5 (mod 6). -/
theorem primes_gt_three_in_channels (p : ℕ) (hp : Nat.Prime p) (hp3 : 3 < p) :
    p % 6 = 1 ∨ p % 6 = 5 := by
  have h_mod : p % 6 = 0 ∨ p % 6 = 1 ∨ p % 6 = 2 ∨ p % 6 = 3 ∨ p % 6 = 4 ∨ p % 6 = 5 := by omega
  rcases h_mod with h0 | h1 | h2 | h3 | h4 | h5
  · exfalso
    have h_div : 2 ∣ p := ⟨3 * (p / 6), by omega⟩
    have hp_eq_2 : 2 = p := (hp.eq_one_or_self_of_dvd 2 h_div).resolve_left (by decide)
    omega
  · exact Or.inl h1
  · exfalso
    have h_div : 2 ∣ p := ⟨3 * (p / 6) + 1, by omega⟩
    have hp_eq_2 : 2 = p := (hp.eq_one_or_self_of_dvd 2 h_div).resolve_left (by decide)
    omega
  · exfalso
    have h_div : 3 ∣ p := ⟨2 * (p / 6) + 1, by omega⟩
    have hp_eq_3 : 3 = p := (hp.eq_one_or_self_of_dvd 3 h_div).resolve_left (by decide)
    omega
  · exfalso
    have h_div : 2 ∣ p := ⟨3 * (p / 6) + 2, by omega⟩
    have hp_eq_2 : 2 = p := (hp.eq_one_or_self_of_dvd 2 h_div).resolve_left (by decide)
    omega
  · exact Or.inr h5

end ATM.Classification
