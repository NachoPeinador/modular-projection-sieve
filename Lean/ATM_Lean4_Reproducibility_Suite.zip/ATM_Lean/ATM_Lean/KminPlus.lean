import Mathlib.Data.Int.Basic
import Mathlib.Tactic.Ring

namespace ATM.KminPlus

def kminPlus (p kp ep : ℤ) : ℤ := p * kp + ep * kp

theorem kminPlus_spec (p kp ep : ℤ) (hp : p = 6 * kp + ep)
    (heps : ep * ep = 1) :
    6 * kminPlus p kp ep + 1 = p ^ 2 := by
  unfold kminPlus
  rw [hp]
  have h_sq : ep ^ 2 = 1 := by rw [sq]; exact heps
  have h : (6 * kp + ep) ^ 2 = 36 * kp ^ 2 + 12 * ep * kp + ep ^ 2 := by ring
  rw [h, h_sq]
  ring

end ATM.KminPlus
