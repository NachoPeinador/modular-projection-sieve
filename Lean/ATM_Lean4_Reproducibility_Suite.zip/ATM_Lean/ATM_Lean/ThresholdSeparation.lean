import Mathlib.Data.Int.Basic
import Mathlib.Tactic

namespace ATM.ThresholdSeparation

/-- Thm 3.8 (i): p^2 < p*q for all 0 < p < q. -/
theorem kmin_plus_lt_pq (p q : ℤ) (hp : 0 < p) (hq : p < q) :
    p^2 < p * q := by
  have h1 : p^2 = p * p := by ring
  rw [h1]
  exact mul_lt_mul_of_pos_left hq hp

/-- Thm 3.8 (ii): for p ∈ C5 (p = 6 kp - 1), under kq ≥ kp,
    the asymmetric threshold strictly dominates the symmetric one. -/
theorem kmin_minus_gt_kmin_plus_C5
    (p kp kq : ℤ) (hp : p = 6 * kp - 1) (hkp : 0 < kp) (hkq : kp ≤ kq) :
    p * kq + kp > p * kp - kp := by
  have hp_pos : 0 < p := by omega
  have hdiff : p * kq + kp - (p * kp - kp) = p * (kq - kp) + 2 * kp := by ring
  have hkq_diff : 0 ≤ kq - kp := by omega
  have hnonneg : 0 ≤ p * (kq - kp) := mul_nonneg (le_of_lt hp_pos) hkq_diff
  have hkp2 : 0 < 2 * kp := by nlinarith
  nlinarith

/-- Thm 3.8 (iii): for p ∈ C1 (p = 6 kp + 1), under kq > kp,
    the asymmetric threshold strictly dominates the symmetric one. -/
theorem kmin_minus_gt_kmin_plus_C1
    (p kp kq : ℤ) (hp : p = 6 * kp + 1) (hkp : 0 < kp) (hkq : kp < kq) :
    p * kq - kp > p * kp + kp := by
  have hp_pos : 0 < p := by omega
  have hdiff : p * kq - kp - (p * kp + kp) = p * (kq - kp) - 2 * kp := by ring
  have hkq_diff : 0 < kq - kp := by omega
  have hprod_pos : 0 < p * (kq - kp) := mul_pos hp_pos hkq_diff
  have hkp2_pos : 0 < 2 * kp := by nlinarith
  nlinarith

end ATM.ThresholdSeparation
