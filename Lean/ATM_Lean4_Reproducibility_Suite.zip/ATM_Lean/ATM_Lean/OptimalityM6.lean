import Mathlib.Data.Nat.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Rat.Defs
import Mathlib.Tactic

namespace ATM.Optimality

def rho (m : ℕ) : ℚ := (Nat.totient m : ℚ) / (m : ℚ)

theorem totient_1 : Nat.totient 1 = 1 := by decide
theorem totient_2 : Nat.totient 2 = 1 := by decide
theorem totient_3 : Nat.totient 3 = 2 := by decide
theorem totient_4 : Nat.totient 4 = 2 := by decide
theorem totient_6 : Nat.totient 6 = 2 := by decide

theorem rho_1 : rho 1 = 1 := by unfold rho; rw [totient_1]; norm_num
theorem rho_2 : rho 2 = 1/2 := by unfold rho; rw [totient_2]; norm_num
theorem rho_3 : rho 3 = 2/3 := by unfold rho; rw [totient_3]; norm_num
theorem rho_4 : rho 4 = 1/2 := by unfold rho; rw [totient_4]; norm_num
theorem rho_6 : rho 6 = 1/3 := by unfold rho; rw [totient_6]; norm_num

/-- Thm 6.1: m = 6 uniquely minimises ρ(m) among φ(m) ≤ 2 -/
theorem rho_six_is_min :
    rho 6 ≤ rho 1 ∧ rho 6 ≤ rho 2 ∧ rho 6 ≤ rho 3 ∧ rho 6 ≤ rho 4 := by
  refine ⟨?_, ?_, ?_, ?_⟩ <;>
    simp [rho_1, rho_2, rho_3, rho_4, rho_6] <;> norm_num

/-- Thm 6.2: Euler factor identities (rational local factors) -/
theorem euler_factor_2 : (1 - 1/(2:ℚ)^2) = 3/4 := by norm_num
theorem euler_factor_3 : (1 - 1/(3:ℚ)^2) = 8/9 := by norm_num
theorem euler_product_6 : (3/4 : ℚ) * (8/9) = 2/3 := by norm_num

end ATM.Optimality
