import Mathlib.Data.Int.Basic
import Mathlib.Tactic.Ring

namespace ATM.Entanglement

/-- Thm 3.7, case (p ∈ C5, q ∈ C1): kappa_min^- = p * kq + kp -/
theorem entanglement_minus_plus (p kp kq kmin : ℤ)
    (hp : p = 6 * kp - 1) (hkmin : kmin = p * kq + kp) :
    6 * kmin - 1 = p * (6 * kq + 1) := by
  rw [hkmin, hp]; ring

/-- Thm 3.7, case (p ∈ C1, q ∈ C5): kappa_min^- = p * kq - kp -/
theorem entanglement_plus_minus (p kp kq kmin : ℤ)
    (hp : p = 6 * kp + 1) (hkmin : kmin = p * kq - kp) :
    6 * kmin - 1 = p * (6 * kq - 1) := by
  rw [hkmin, hp]; ring

/-- Thm 3.7, case (p ∈ C5, q ∈ C5): kappa_min^+ = p * kq - kp -/
theorem entanglement_minus_minus (p kp kq kmin : ℤ)
    (hp : p = 6 * kp - 1) (hkmin : kmin = p * kq - kp) :
    6 * kmin + 1 = p * (6 * kq - 1) := by
  rw [hkmin, hp]; ring

/-- Thm 3.7, case (p ∈ C1, q ∈ C1): kappa_min^+ = p * kq + kp -/
theorem entanglement_plus_plus (p kp kq kmin : ℤ)
    (hp : p = 6 * kp + 1) (hkmin : kmin = p * kq + kp) :
    6 * kmin + 1 = p * (6 * kq + 1) := by
  rw [hkmin, hp]; ring

/-- Definition of entanglement jump Δk = kq - kp -/
def entanglementJump (kp kq : ℤ) : ℤ := kq - kp

/-- Twin-prime ground state condition: Δk = 0 iff kq = kp -/
theorem ground_state_iff_jump_zero (kp kq : ℤ) :
    entanglementJump kp kq = 0 ↔ kq = kp := by
  unfold entanglementJump; omega

end ATM.Entanglement
