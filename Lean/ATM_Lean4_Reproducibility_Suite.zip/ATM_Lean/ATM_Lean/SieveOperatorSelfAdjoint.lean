import Mathlib.Data.Matrix.Basic
import Mathlib.Tactic

open Matrix

namespace ATM.SieveOperator

variable {k_idx p_idx : Type*} [Fintype k_idx] [Fintype p_idx]
variable {α : Type*} [CommRing α]

/-- The sieve operator H_N = M M^T is symmetric. -/
theorem sieve_operator_is_symmetric (M : Matrix k_idx p_idx α) :
    (M * M.transpose).transpose = M * M.transpose := by
  simp

end ATM.SieveOperator
