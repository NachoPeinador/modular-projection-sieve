import Mathlib.Data.Int.Basic
import Mathlib.Algebra.GCDMonoid.Basic
import Mathlib.Tactic

namespace ATM.Positional

/-- Auxiliary lemma: Euclid's lemma via Bézout's identity. -/
lemma dvd_of_dvd_mul_6 (p X : ℤ)
    (h1 : ∃ c : ℤ, 6 * X = p * c)
    (hcoprime : ∃ a b : ℤ, a * p + b * 6 = 1) :
    ∃ d : ℤ, X = p * d := by
  rcases hcoprime with ⟨a, b, hab⟩
  rcases h1 with ⟨c, hc⟩
  use a * X + b * c
  calc X
    _ = X * 1 := by ring
    _ = X * (a * p + b * 6) := by rw [hab]
    _ = a * X * p + b * (6 * X) := by ring
    _ = a * X * p + b * (p * c) := by rw [hc]
    _ = p * (a * X + b * c) := by ring

/-- Lemma 3.1 (corrected sign): p | 6k + eps ↔ p | (k - eps*ep*kp). -/
theorem positional_congruence (k kp p ep eps : ℤ)
    (hp : p = 6 * kp + ep)
    (hep : ep * ep = 1)
    (hcop : IsCoprime (6 : ℤ) p) :
    (∃ c, 6 * k + eps = p * c) ↔
    (∃ d, k - ep * eps * kp = p * d) := by
  have h_alg : (6 * k + eps) - p * (ep * eps) = 6 * (k - ep * eps * kp) := by
    calc (6 * k + eps) - p * (ep * eps)
      _ = 6 * k + eps - (6 * kp + ep) * (ep * eps) := by rw [hp]
      _ = 6 * k + eps - 6 * kp * ep * eps - (ep * ep) * eps := by ring
      _ = 6 * k + eps - 6 * kp * ep * eps - 1 * eps := by rw [hep]
      _ = 6 * (k - ep * eps * kp) := by ring
  obtain ⟨a, b, hab⟩ := hcop
  have hbez : ∃ a b : ℤ, a * p + b * 6 = 1 := ⟨b, a, by linarith [hab]⟩
  constructor
  · intro h
    rcases h with ⟨c, hc⟩
    have h1 : 6 * (k - ep * eps * kp) = p * (c - ep * eps) := by
      calc 6 * (k - ep * eps * kp)
        _ = (6 * k + eps) - p * (ep * eps) := by rw [h_alg]
        _ = p * c - p * (ep * eps) := by rw [hc]
        _ = p * (c - ep * eps) := by ring
    exact dvd_of_dvd_mul_6 p (k - ep * eps * kp) ⟨c - ep * eps, h1⟩ hbez
  · intro h
    rcases h with ⟨d, hd⟩
    refine ⟨6 * d + ep * eps, ?_⟩
    calc 6 * k + eps
      _ = 6 * (k - ep * eps * kp) + p * (ep * eps) := by
        calc 6 * k + eps
          _ = (6 * k + eps) - p * (ep * eps) + p * (ep * eps) := by ring
          _ = 6 * (k - ep * eps * kp) + p * (ep * eps) := by rw [h_alg]
      _ = 6 * (p * d) + p * (ep * eps) := by rw [hd]
      _ = p * (6 * d + ep * eps) := by ring

/-- §3.1 corollary (N1): no annihilation ↔ no positional congruence.
    Contrapositive form of Lemma 3.1, used in §4.2 (ground state). -/
theorem no_annihilation_iff_no_congruence (k kp p ep eps : ℤ)
    (hp : p = 6 * kp + ep)
    (hep : ep * ep = 1)
    (hcop : IsCoprime (6 : ℤ) p) :
    ¬(∃ c, 6 * k + eps = p * c) ↔
    ¬(∃ d, k - ep * eps * kp = p * d) := by
  exact (not_iff_not).2 (positional_congruence k kp p ep eps hp hep hcop)

end ATM.Positional
