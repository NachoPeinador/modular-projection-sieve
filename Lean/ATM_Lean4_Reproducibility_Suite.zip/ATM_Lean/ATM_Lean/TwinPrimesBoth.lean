import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

namespace ATM.Channel

/-- El canal C1 está bloqueado en el índice k por el primo p. -/
def B_C1 (k : ℤ) (p : ℤ) : Prop := p ∣ (6 * k + 1)

/-- El canal C5 está bloqueado en el índice k por el primo p. -/
def B_C5 (k : ℤ) (p : ℤ) : Prop := p ∣ (6 * k - 1)

/-- La involución quiral transforma un bloqueo en C1 en k en un bloqueo en C5 en -k. -/
theorem chiral_involution_C1_C5 (k : ℤ) (p : ℤ) :
    B_C1 k p ↔ B_C5 (-k) p := by
  dsimp [B_C1, B_C5]
  constructor
  · rintro ⟨c, hc⟩
    refine ⟨-c, ?_⟩
    calc 6 * (-k) - 1
      _ = -(6 * k + 1) := by ring
      _ = -(p * c) := by rw [hc]
      _ = p * (-c) := by ring
  · rintro ⟨c, hc⟩
    refine ⟨-c, ?_⟩
    calc 6 * k + 1
      _ = -(6 * (-k) - 1) := by ring
      _ = -(p * c) := by rw [hc]
      _ = p * (-c) := by ring

/-- La involución quiral transforma un bloqueo en C5 en k en un bloqueo en C1 en -k. -/
theorem chiral_involution_C5_C1 (k : ℤ) (p : ℤ) :
    B_C5 k p ↔ B_C1 (-k) p := by
  dsimp [B_C1, B_C5]
  constructor
  · rintro ⟨c, hc⟩
    refine ⟨-c, ?_⟩
    calc 6 * (-k) + 1
      _ = -(6 * k - 1) := by ring
      _ = -(p * c) := by rw [hc]
      _ = p * (-c) := by ring
  · rintro ⟨c, hc⟩
    refine ⟨-c, ?_⟩
    calc 6 * k - 1
      _ = -(6 * (-k) + 1) := by ring
      _ = -(p * c) := by rw [hc]
      _ = p * (-c) := by ring

end ATM.Channel

namespace ATM.TwinPrimesBoth

open Finset
open ATM.Channel (B_C1 B_C5 chiral_involution_C1_C5 chiral_involution_C5_C1)

-- ============================================================================
-- 1. BLOQUEO BILATERAL: DEFINICIÓN Y ESTRUCTURA
-- ============================================================================

/-- Bloqueo bilateral: ambos canales están bloqueados por primos de la base. -/
def B_both (k : ℤ) (primes : Finset ℕ) : Prop :=
  (∃ p ∈ primes, B_C1 k (p : ℤ)) ∧ (∃ q ∈ primes, B_C5 k (q : ℤ))

/-- Teorema N1: un único primo p ≥ 5 jamás bloquea ambos canales a la vez. -/
theorem single_prime_cannot_block_both (k : ℤ) (p : ℤ) (hp : 5 ≤ p) :
    ¬ (B_C1 k p ∧ B_C5 k p) := by
  dsimp [B_C1, B_C5]
  rintro ⟨h1, h2⟩
  have h_diff : p ∣ (6 * k + 1) - (6 * k - 1) := dvd_sub h1 h2
  have h_eq : (6 * k + 1) - (6 * k - 1) = 2 := by ring
  rw [h_eq] at h_diff
  rcases h_diff with ⟨c, hc⟩
  have h_c_pos : 0 < c := by
    by_contra! h_le
    have : p * c ≤ 0 := by nlinarith
    linarith
  have h_ge : 5 ≤ p * c := by nlinarith
  linarith

/-- Teorema N1: todo bloqueo bilateral exige dos primos distintos. -/
theorem bilateral_block_requires_distinct_primes
    (k : ℤ) (primes : Finset ℕ)
    (h_ge5 : ∀ p ∈ primes, 5 ≤ (p : ℤ))
    (p q : ℕ) (hp : p ∈ primes) (hq : q ∈ primes)
    (h_c1 : B_C1 k (p : ℤ)) (h_c5 : B_C5 k (q : ℤ)) :
    p ≠ q := by
  rintro rfl
  exact single_prime_cannot_block_both k (p : ℤ) (h_ge5 p hp) ⟨h_c1, h_c5⟩

/-- Teorema N1: para la base singleton {5}, el bloqueo bilateral es imposible. -/
theorem no_bilateral_block_singleton_five (k : ℤ) :
    ¬ B_both k {5} := by
  rintro ⟨⟨p, hp, h_c1⟩, ⟨q, hq, h_c5⟩⟩
  rw [mem_singleton] at hp hq
  subst hp hq
  exact single_prime_cannot_block_both k 5 (by norm_num) ⟨h_c1, h_c5⟩

-- ============================================================================
-- 2. JERARQUÍA LÓGICA DE INCLUSIÓN QUIRAL
-- ============================================================================

/-- Teorema N1: el bloqueo bilateral implica lógicamente el bloqueo en C1. -/
theorem both_implies_C1 (k : ℤ) (primes : Finset ℕ) :
    B_both k primes → (∃ p ∈ primes, B_C1 k (p : ℤ)) :=
  fun h => h.1

/-- Teorema N1: el bloqueo bilateral implica lógicamente el bloqueo en C5. -/
theorem both_implies_C5 (k : ℤ) (primes : Finset ℕ) :
    B_both k primes → (∃ q ∈ primes, B_C5 k (q : ℤ)) :=
  fun h => h.2

/-- Teorema N1: la involución quiral k ↦ -k permuta los testigos del bloqueo
    bilateral, intercambiando C1 y C5 sin ambigüedad de tipos. -/
theorem bilateral_block_chiral_involution (k : ℤ) (primes : Finset ℕ) :
    B_both k primes ↔ B_both (-k) primes := by
  dsimp [B_both]
  constructor
  · rintro ⟨⟨p, hp, h1⟩, ⟨q, hq, h2⟩⟩
    refine ⟨⟨q, hq, (chiral_involution_C5_C1 k (q : ℤ)).mp h2⟩,
            ⟨p, hp, (chiral_involution_C1_C5 k (p : ℤ)).mp h1⟩⟩
  · rintro ⟨⟨q, hq, h1⟩, ⟨p, hp, h2⟩⟩
    refine ⟨⟨p, hp, (chiral_involution_C1_C5 k (p : ℤ)).mpr h2⟩,
            ⟨q, hq, (chiral_involution_C5_C1 k (q : ℤ)).mpr h1⟩⟩

-- ============================================================================
-- 3. JERARQUÍA DE RACHAS: DE LO BILATERAL A LO MONO-CANAL
-- ============================================================================

/-- Una racha bilateral de longitud L a partir del índice k0. -/
def is_bilateral_run (primes : Finset ℕ) (k0 L : ℤ) : Prop :=
  0 < L ∧ ∀ j, 0 ≤ j → j < L → B_both (k0 + j) primes

/-- Una racha mono-canal C1 de longitud L a partir del índice k0. -/
def is_C1_run (primes : Finset ℕ) (k0 L : ℤ) : Prop :=
  0 < L ∧ ∀ j, 0 ≤ j → j < L → ∃ p ∈ primes, B_C1 (k0 + j) (p : ℤ)

/-- Una racha mono-canal C5 de longitud L a partir del índice k0. -/
def is_C5_run (primes : Finset ℕ) (k0 L : ℤ) : Prop :=
  0 < L ∧ ∀ j, 0 ≤ j → j < L → ∃ q ∈ primes, B_C5 (k0 + j) (q : ℤ)

/-- Teorema N1: toda racha bilateral de longitud L contiene una racha C1
    de la misma longitud. -/
theorem bilateral_run_implies_C1_run
    (primes : Finset ℕ) (k0 L : ℤ) (h : is_bilateral_run primes k0 L) :
    is_C1_run primes k0 L := by
  rcases h with ⟨hL, hrun⟩
  refine ⟨hL, ?_⟩
  intro j hj0 hjL
  exact both_implies_C1 (k0 + j) primes (hrun j hj0 hjL)

/-- Teorema N1: toda racha bilateral de longitud L contiene una racha C5
    de la misma longitud. -/
theorem bilateral_run_implies_C5_run
    (primes : Finset ℕ) (k0 L : ℤ) (h : is_bilateral_run primes k0 L) :
    is_C5_run primes k0 L := by
  rcases h with ⟨hL, hrun⟩
  refine ⟨hL, ?_⟩
  intro j hj0 hjL
  exact both_implies_C5 (k0 + j) primes (hrun j hj0 hjL)

-- ============================================================================
-- 4. VENTANA DE PRIMALIDAD Y DOMINANCIA ASINTÓTICA
-- ============================================================================

/-- Escala canónica del intervalo de búsqueda de primos: X ≈ z^2 / 6. -/
noncomputable def X_window (z : ℝ) : ℝ := (z ^ 2) / 6

/-- Teorema N1: la ventana es estrictamente positiva para z > 0. -/
theorem X_window_pos (z : ℝ) (hz : 0 < z) : 0 < X_window z := by
  dsimp [X_window]
  have : 0 < z ^ 2 := sq_pos_of_pos hz
  linarith

/-- Teorema N1: la ventana X(z) domina asintóticamente a cualquier cota
    lineal Cz. -/
theorem X_window_eventually_dominates_linear (C : ℝ) :
    ∃ z0 : ℝ, ∀ z ≥ z0, C * z < X_window z := by
  refine ⟨|6 * C| + 1, ?_⟩
  intro z hz
  have hz_pos : 0 < z := by
    have : 0 ≤ |6 * C| := abs_nonneg _
    linarith
  dsimp [X_window]
  have h_bound : 6 * C < z := by
    have h_le : 6 * C ≤ |6 * C| := le_abs_self _
    linarith
  have h_mul : 6 * C * z < z * z := mul_lt_mul_of_pos_right h_bound hz_pos
  have h_sq : z * z = z ^ 2 := by ring
  rw [h_sq] at h_mul
  linarith

end ATM.TwinPrimesBoth
