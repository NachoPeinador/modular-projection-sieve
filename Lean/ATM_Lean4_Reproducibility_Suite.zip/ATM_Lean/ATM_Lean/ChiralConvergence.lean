import Mathlib.Basic.Real.Basic
import Mathlib.Tactic

namespace ATM.ChiralConvergence

/-- §7.3 (N1): algebraic core of the chiral convergence, c1/c5 = 1 + (c1-c5)/c5. -/
theorem chiral_ratio_identity
    (c1 c5 : ℕ → ℝ) (N : ℕ) (h : c5 N ≠ 0) :
    c1 N / c5 N = 1 + (c1 N - c5 N) / c5 N := by
  field_simp
  ring

/-- §7.3 (N1): reformulation as difference from 1. -/
theorem chiral_ratio_diff
    (c1 c5 : ℕ → ℝ) (N : ℕ) (h : c5 N ≠ 0) :
    c1 N / c5 N - 1 = (c1 N - c5 N) / c5 N := by
  rw [chiral_ratio_identity c1 c5 N h]
  ring

end ATM.ChiralConvergence
