import Mathlib.Data.Int.Basic
import Mathlib.Data.Nat.Prime.Basic

namespace ATM.Cop

/-- Def 3.5: A prime q is a valid positional coprime of p = 6kp + ep
    if q lies in the opposite channel and its index satisfies the
    asymmetric condition. -/
def IsCop (p kp ep : ℤ) (q kq : ℤ) : Prop :=
  q = 6 * kq - ep ∧
  (if ep = -1 then kq ≥ kp else kq ≥ kp + 1)

/-- Def 3.5: The entanglement jump -/
def deltaK (kp kq : ℤ) : ℤ := kq - kp

/-- Remark 3.5.1 (why the asymmetric condition is necessary, C1 case):
    For p ∈ C1, if kq = kp, then q = p - 2 < p, and the product p*q has
    already been sieved by q. The strict inequality kq ≥ kp + 1 excludes
    this redundancy. Encoded as a purely arithmetic implication. -/
theorem why_asymmetric_c1 (p kp q kq : ℤ) (hp : p = 6 * kp + 1)
    (hq : q = 6 * kq - 1) (hkq : kq = kp) :
    q = p - 2 := by
  subst hkq; omega

/-- Thm 3.6 (N1-P): existence of Cop(p).
    The hypothesis `h_dirichlet` is the parameterised form of Dirichlet's
    theorem: there exists a prime q in the opposite channel whose index
    satisfies the asymmetric condition. This sanitises the analytic
    input (Dirichlet) as an explicit theorem hypothesis, eliminating
    any global axiom. -/
theorem cop_exists (p kp ep : ℤ)
    (h_dirichlet : ∃ q kq : ℤ, IsCop p kp ep q kq) :
    ∃ q kq : ℤ, IsCop p kp ep q kq := h_dirichlet

end ATM.Cop
