import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

namespace ATM.Complexity

noncomputable def memoryBound (N : ℝ) : ℝ := Real.sqrt N / Real.log N
theorem memory_def (N : ℝ) : memoryBound N = Real.sqrt N / Real.log N := rfl

theorem memory_positive (N : ℝ) (hN : 1 < N) : 0 < memoryBound N := by
  unfold memoryBound
  apply div_pos
  · exact Real.sqrt_pos_of_pos (by linarith)
  · exact Real.log_pos hN

noncomputable def timeBound (N : ℝ) : ℝ := N ^ (3 / 2 : ℝ) / Real.log N
theorem time_def (N : ℝ) : timeBound N = N ^ (3 / 2 : ℝ) / Real.log N := rfl

end ATM.Complexity
