import Mathlib.Data.Nat.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Tactic

namespace ATM.GroundState

/-- Twin-generation predicate: k generates a twin-prime pair iff both
    6k-1 and 6k+1 are prime. -/
def GeneraGemelos (k : ℕ) : Prop :=
  Nat.Prime (6 * k - 1) ∧ Nat.Prime (6 * k + 1)

/-- The quadratic annihilator (paper: eq:twin-annihilator). -/
def annihilator (k kp : ℤ) : ℤ := k ^ 2 - kp ^ 2

/-- Necessity: if k generates twins, then no prime p < 6k-1 divides
    either channel. -/
theorem condicion_necesaria_gemelos (k : ℕ) (hk : GeneraGemelos k) :
    ∀ p : ℕ, Nat.Prime p → p < 6 * k - 1 →
      ¬(p ∣ 6 * k - 1) ∧ ¬(p ∣ 6 * k + 1) := by
  intro p hp h_lt
  rcases hk with ⟨h_minus, h_plus⟩
  constructor
  · intro h_div
    have h_eq_or := (Nat.Prime.eq_one_or_self_of_dvd h_minus p) h_div
    rcases h_eq_or with rfl | rfl
    · exact Nat.not_prime_one hp
    · exact lt_irrefl _ h_lt
  · intro h_div
    have h_lt_plus : p < 6 * k + 1 := by omega
    have h_eq_or := (Nat.Prime.eq_one_or_self_of_dvd h_plus p) h_div
    rcases h_eq_or with rfl | rfl
    · exact Nat.not_prime_one hp
    · exact lt_irrefl _ h_lt_plus

/-- Sufficiency: if no prime p with p² ≤ 6k+1 divides either channel,
    then k generates twins. -/
theorem condicion_suficiente_gemelos (k : ℕ) (hk0 : 0 < k)
    (h_oraculo : ∀ p : ℕ, Nat.Prime p → p * p ≤ 6 * k + 1 →
      ¬(p ∣ 6 * k - 1) ∧ ¬(p ∣ 6 * k + 1)) :
    GeneraGemelos k := by
  have h_gt1_m : 1 < 6 * k - 1 := by omega
  have h_pos_m : 0 < 6 * k - 1 := by omega
  have h_gt1_p : 1 < 6 * k + 1 := by omega
  have h_pos_p : 0 < 6 * k + 1 := by omega
  constructor
  · by_contra h_comp
    have hp_prime := Nat.minFac_prime h_gt1_m.ne'
    have hp_dvd := Nat.minFac_dvd (6 * k - 1)
    have hp_sq : (Nat.minFac (6 * k - 1)) ^ 2 ≤ 6 * k - 1 :=
      Nat.minFac_sq_le_self h_pos_m h_comp
    have hp_le : (Nat.minFac (6 * k - 1)) * (Nat.minFac (6 * k - 1)) ≤ 6 * k + 1 := by
      calc (Nat.minFac (6 * k - 1)) * (Nat.minFac (6 * k - 1))
        _ = (Nat.minFac (6 * k - 1)) ^ 2 := by ring
        _ ≤ 6 * k - 1 := hp_sq
        _ ≤ 6 * k + 1 := by omega
    exact (h_oraculo (Nat.minFac (6 * k - 1)) hp_prime hp_le).left hp_dvd
  · by_contra h_comp
    have hp_prime := Nat.minFac_prime h_gt1_p.ne'
    have hp_dvd := Nat.minFac_dvd (6 * k + 1)
    have hp_sq : (Nat.minFac (6 * k + 1)) ^ 2 ≤ 6 * k + 1 :=
      Nat.minFac_sq_le_self h_pos_p h_comp
    have hp_le : (Nat.minFac (6 * k + 1)) * (Nat.minFac (6 * k + 1)) ≤ 6 * k + 1 := by
      calc (Nat.minFac (6 * k + 1)) * (Nat.minFac (6 * k + 1))
        _ = (Nat.minFac (6 * k + 1)) ^ 2 := by ring
        _ ≤ 6 * k + 1 := hp_sq
    exact (h_oraculo (Nat.minFac (6 * k + 1)) hp_prime hp_le).right hp_dvd

/-- Theorem thm:ground-state (N1): complete equivalence. -/
theorem equivalencia_gemelos (k : ℕ) (hk0 : 0 < k) :
    GeneraGemelos k ↔
    (∀ p : ℕ, Nat.Prime p → p * p ≤ 6 * k + 1 →
      ¬(p ∣ 6 * k - 1) ∧ ¬(p ∣ 6 * k + 1)) := by
  constructor
  · intro hk p hp h_sq
    rcases hk with ⟨hm, hp_prime⟩
    constructor
    · intro hdiv
      have h_eq := (Nat.Prime.eq_one_or_self_of_dvd hm p) hdiv
      rcases h_eq with rfl | rfl
      · exact Nat.not_prime_one hp
      · have hk_ge : 1 ≤ k := hk0
        have h_bound : 5 ≤ 6 * k - 1 := by omega
        have h_mul := Nat.mul_le_mul_left (6 * k - 1) h_bound
        omega
    · intro hdiv
      have h_eq := (Nat.Prime.eq_one_or_self_of_dvd hp_prime p) hdiv
      rcases h_eq with rfl | rfl
      · exact Nat.not_prime_one hp
      · have hk_ge : 1 ≤ k := hk0
        have h_bound : 7 ≤ 6 * k + 1 := by omega
        have h_mul := Nat.mul_le_mul_left (6 * k + 1) h_bound
        omega
  · intro h
    exact condicion_suficiente_gemelos k hk0 h

end ATM.GroundState
