import Mathlib.Data.Int.Basic
import Mathlib.Data.Int.Basic
import Mathlib.RingTheory.Coprime.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith

namespace ATM.Composite

/-- Lema de Euclides vía Bézout: si p divide a 6*X y mcd(6, p) = 1, entonces p divide a X.
    Demostrado puramente mediante álgebra de anillos en ℤ con cero axiomas. -/
lemma dvd_of_dvd_mul_six (p X : ℤ)
    (h1 : p ∣ (6 * X))
    (hcoprime : IsCoprime (6 : ℤ) p) :
    p ∣ X := by
  unfold IsCoprime at hcoprime
  rcases hcoprime with ⟨a, b, hab⟩
  rcases h1 with ⟨c, hc⟩
  use a * c + b * X
  calc X
    _ = (a * 6 + b * p) * X := by rw [hab, one_mul]
    _ = a * (6 * X) + b * p * X := by ring
    _ = a * (p * c) + b * p * X := by rw [hc]
    _ = p * (a * c + b * X) := by ring

/-- Lema Fundamental de Congruencia Posicional:
    p divide al candidato 6k + eps si y solo si p divide a (k - ep*eps*kp). -/
lemma positional_congruence (k kp p ep eps : ℤ)
    (hp : p = 6 * kp + ep)
    (hep : ep * ep = 1)
    (hcop : IsCoprime (6 : ℤ) p) :
    p ∣ (6 * k + eps) ↔ p ∣ (k - ep * eps * kp) := by
  have h_alg : 6 * (k - ep * eps * kp) = (6 * k + eps) - p * (ep * eps) := by
    calc 6 * (k - ep * eps * kp)
      _ = 6 * k + eps - 6 * kp * ep * eps - 1 * eps := by ring
      _ = 6 * k + eps - 6 * kp * ep * eps - (ep * ep) * eps := by rw [hep]
      _ = 6 * k + eps - (6 * kp + ep) * (ep * eps) := by ring
      _ = (6 * k + eps) - p * (ep * eps) := by rw [hp]
  constructor
  · intro h_div
    rcases h_div with ⟨c, hc⟩
    have h_mul : p ∣ 6 * (k - ep * eps * kp) := by
      use c - ep * eps
      calc 6 * (k - ep * eps * kp)
        _ = (6 * k + eps) - p * (ep * eps) := h_alg
        _ = p * c - p * (ep * eps) := by rw [hc]
        _ = p * (c - ep * eps) := by ring
    exact dvd_of_dvd_mul_six p (k - ep * eps * kp) h_mul hcop
  · intro h_div
    rcases h_div with ⟨d, hd⟩
    use 6 * d + ep * eps
    calc 6 * k + eps
      _ = 6 * (k - ep * eps * kp) + p * (ep * eps) := by
        rw [h_alg]
        ring
      _ = 6 * (p * d) + p * (ep * eps) := by rw [hd]
      _ = p * (6 * d + ep * eps) := by ring

/-- Proposición 3.2 (Implicación Directa):
    Si p ∈ 𝒫_{>3} divide al candidato 6k+eps y es divisor propio (6k+eps ≠ p),
    entonces k pertenece necesariamente al conjunto de ramificación S_p. -/
theorem composite_forward_local
    (k kp p ep eps : ℤ)
    (hp : p = 6 * kp + ep)
    (hep : ep * ep = 1)
    (heps : eps = 1 ∨ eps = -1)
    (hep_cases : ep = 1 ∨ ep = -1)
    (hk : 0 < k)
    (_hkp : 0 < kp)
    (hp_pos : 0 < p)
    (hcop : IsCoprime (6 : ℤ) p)
    (h_div : p ∣ (6 * k + eps))
    (h_ne : 6 * k + eps ≠ p) :
    (eps = ep ∧ p ∣ (k - kp) ∧ k > kp) ∨ (eps = -ep ∧ p ∣ (k + kp)) := by
  have h_cong := (positional_congruence k kp p ep eps hp hep hcop).mp h_div
  by_cases h_sign : eps = ep
  · left
    have h_prod : ep * eps = 1 := by
      calc ep * eps
        _ = ep * ep := by rw [h_sign]
        _ = 1 := hep
    have h_dvd_sub : p ∣ (k - kp) := by
      have h_sub : k - ep * eps * kp = k - kp := by rw [h_prod, one_mul]
      rw [h_sub] at h_cong
      exact h_cong
    refine ⟨h_sign, h_dvd_sub, ?_⟩
    rcases h_dvd_sub with ⟨m, hm⟩
    by_contra h_not_gt
    have h_k_le : k ≤ kp := by omega
    have h_sub_le : k - kp ≤ 0 := by omega
    have h_m_le : m ≤ 0 := by
      by_contra hm_pos
      have hm_ge : 1 ≤ m := by omega
      have h_pm : p ≤ p * m := by nlinarith
      have : p ≤ 0 := by linarith [hm, h_pm, h_sub_le]
      linarith [hp_pos]
    have h_m_ge : 0 ≤ m := by
      by_contra hm_neg
      have hm_le : m ≤ -1 := by omega
      have h_pm : p * m ≤ -p := by nlinarith
      have h_k_le_neg : k - kp ≤ -p := by linarith [hm, h_pm]
      rcases hep_cases with h1 | h2
      · rw [h1] at hp; omega
      · rw [h2] at hp; omega
    have hm_zero : m = 0 := by omega
    have hk_eq : k = kp := by
      calc k
        _ = kp + (k - kp) := by ring
        _ = kp + p * m := by rw [hm]
        _ = kp := by rw [hm_zero, mul_zero, add_zero]
    have h_cand_eq : 6 * k + eps = p := by
      calc 6 * k + eps
        _ = 6 * kp + ep := by rw [hk_eq, h_sign]
        _ = p := hp.symm
    exact h_ne h_cand_eq
  · right
    have h_eps_neg : eps = -ep := by
      rcases heps with rfl | rfl <;> rcases hep_cases with rfl | rfl <;>
        (try rfl) <;> (exfalso; exact h_sign rfl)
    have h_prod_neg : ep * eps = -1 := by
      calc ep * eps
        _ = ep * (-ep) := by rw [h_eps_neg]
        _ = -(ep * ep) := by ring
        _ = -1 := by rw [hep]
    have h_dvd_add : p ∣ (k + kp) := by
      have h_add : k - ep * eps * kp = k + kp := by
        calc k - ep * eps * kp
          _ = k - (-1) * kp := by rw [h_prod_neg]
          _ = k + kp := by ring
      rw [h_add] at h_cong
      exact h_cong
    exact ⟨h_eps_neg, h_dvd_add⟩

/-- Proposición 3.2 (Implicación Recíproca):
    Si k pertenece al conjunto de ramificación S_p de un primo p ∈ 𝒫_{>3},
    entonces el candidato 6k+eps es un múltiplo propio no trivial de p. -/
theorem composite_backward_local
    (k kp p ep eps : ℤ)
    (hp : p = 6 * kp + ep)
    (hep : ep * ep = 1)
    (hk : 0 < k)
    (hkp : 0 < kp)
    (hep_cases : ep = 1 ∨ ep = -1)
    (h_branch : (eps = ep ∧ p ∣ (k - kp) ∧ k > kp) ∨ (eps = -ep ∧ p ∣ (k + kp)))
    (hcop : IsCoprime (6 : ℤ) p) :
    p ∣ (6 * k + eps) ∧ p < 6 * k + eps := by
  have hp_pos : 0 < p := by
    rcases hep_cases with h1 | h2
    · rw [h1] at hp; omega
    · rw [h2] at hp; omega
  rcases h_branch with ⟨h_same, h_dvd, h_gt⟩ | ⟨h_opp, h_dvd⟩
  · have h_prod : ep * eps = 1 := by
      calc ep * eps = ep * ep := by rw [h_same]
      _ = 1 := hep
    have h_dvd' : p ∣ (k - ep * eps * kp) := by
      have : k - ep * eps * kp = k - kp := by rw [h_prod, one_mul]
      rw [this]
      exact h_dvd
    have h_div_cand := (positional_congruence k kp p ep eps hp hep hcop).mpr h_dvd'
    have h_gt_cand : p < 6 * k + eps := by
      have hk_ge : kp + 1 ≤ k := by omega
      have h_eps_eq : eps = ep := h_same
      omega
    exact ⟨h_div_cand, h_gt_cand⟩
  · have h_prod : ep * eps = -1 := by
      calc ep * eps = ep * (-ep) := by rw [h_opp]
      _ = -(ep * ep) := by ring
      _ = -1 := by rw [hep]
    have h_dvd' : p ∣ (k - ep * eps * kp) := by
      have : k - ep * eps * kp = k + kp := by
        rw [h_prod]
        ring
      rw [this]
      exact h_dvd
    have h_div_cand := (positional_congruence k kp p ep eps hp hep hcop).mpr h_dvd'
    have h_gt_cand : p < 6 * k + eps := by
      rcases h_dvd with ⟨m, hm⟩
      have hm_pos : 1 ≤ m := by
        by_contra h_neg
        have hm_le : m ≤ 0 := by omega
        have h_pm : p * m ≤ 0 := by nlinarith [hp_pos, hm_le]
        have h_sum : 0 < k + kp := by omega
        linarith [hm, h_sum, h_pm]
      have h_pm_ge : p ≤ p * m := by nlinarith [hp_pos, hm_pos]
      have hk_ge : p - kp ≤ k := by linarith [hm, h_pm_ge]
      linarith [hk_ge, hp, h_opp, hp_pos]
    exact ⟨h_div_cand, h_gt_cand⟩

/-- Teorema Estructural 3.2 (Equivalencia Completa de Ramificación N1):
    Un índice k produce un candidato divisible por p y estrictamente compuesto
    si y solo si k pertenece a la rama correspondiente de S_p.
    Completamente verificado con 0 sorry y 0 axiomas. -/
theorem composite_branching_iff
    (k kp p ep eps : ℤ)
    (hp : p = 6 * kp + ep)
    (hep : ep * ep = 1)
    (heps : eps = 1 ∨ eps = -1)
    (hep_cases : ep = 1 ∨ ep = -1)
    (hk : 0 < k)
    (hkp : 0 < kp)
    (hp_pos : 0 < p)
    (hcop : IsCoprime (6 : ℤ) p) :
    (p ∣ (6 * k + eps) ∧ 6 * k + eps ≠ p) ↔
    ((eps = ep ∧ p ∣ (k - kp) ∧ k > kp) ∨ (eps = -ep ∧ p ∣ (k + kp))) := by
  constructor
  · intro ⟨h_div, h_ne⟩
    exact composite_forward_local k kp p ep eps hp hep heps hep_cases hk hkp hp_pos hcop h_div h_ne
  · intro h_branch
    have h_prop := composite_backward_local k kp p ep eps hp hep hk hkp hep_cases h_branch hcop
    exact ⟨h_prop.left, ne_of_gt h_prop.right⟩

end ATM.Composite
