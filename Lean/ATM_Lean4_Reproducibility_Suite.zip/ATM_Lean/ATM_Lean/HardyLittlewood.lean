import Mathlib.Basic.Real.Basic
import Mathlib.Tactic

namespace ATM.HL

noncomputable def localFactor (p : ℝ) : ℝ := 1 - 1 / (p - 1) ^ 2

/-- Thm 4.4 (algebraic identity): localFactor(p) = (p-2)*p / (p-1)^2 -/
theorem local_factor_identity (p : ℝ) (hp : p ≠ 1) :
    localFactor p = (p - 2) * p / (p - 1) ^ 2 := by
  unfold localFactor
  have h : (p - 1) ^ 2 ≠ 0 := by
    apply pow_ne_zero
    exact sub_ne_zero.mpr hp
  field_simp
  ring

/-- Thm 4.4 at p = 5 (numerical anchor) -/
theorem local_factor_at_5 :
    localFactor 5 = (5 - 2) * 5 / (5 - 1) ^ 2 := by
  apply local_factor_identity
  norm_num

end ATM.HL
